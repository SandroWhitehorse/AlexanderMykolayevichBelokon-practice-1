/*
 * Class Tasc
 *
 * V1.1
 * This class using to create and not repitative and repitative task
 *
 * author: Alexander Mykolayevich Belokon
 */
package com.nc.edu.ta.AlexanderMykolayevichBelokon.pr1.task;

public class Task {
        private String title = null; // private variable for title of task
        private boolean active = false; // private variable for
        private int time = 0; //
        private int start = 0; //
        private int end = 0; //
        private int repeat = 0; //
        private int startTime = 0; //
        private int endTime = 0; //
        private int repeatInterval = 0; //
        private boolean isRepeated = false; //
        private int nextTimeAfter = 0; //

        // getTitle() is for returning title string
        public String getTitle() {
                return title;
        }

        // setTitle(String title) is for setting string from parameter
        // title in private variable title in class Task
        public void setTitle(String title) {
                this.title = title;

        }

        // IsActive() return boolean that means: is this an active task
        public boolean isActive() {

                return this.active;
        }

        // setActive(boolean active) set in private variable in class
        // Task parameter active which means : is this task active
        public void setActive(boolean active) {

                this.active = active;
        }

        // setTime(int time) set time for not repeatable  task
        // and change isRepeated variable for
        public void setTime(int time) {
                this.time = time;
                if (this.isRepeated) {
                        this.time = time;
                        this.isRepeated = false;
                }

        }

        // This method sets times of start end and repeating time interval
        // for repeatable Task
        public void setTime(int start, int end, int repeat) {
                this.start = start;
                this.end = end;
                this.repeat = repeat;
                this.isRepeated = true;
        }

        //method getTime must return time Task
        public int getTime() {
                if (this.isRepeated()) {
                        return this.startTime;
        }
                else {
                        return this.time;
                }
        }

        //method int GetStream must return int for task start time
        public int getStartTime() {
                if (this.isRepeated()) {
                return this.startTime;
        } else {
            return this.time;
        }
        }

        //this method need return end time of task
        public int getEndTime() {
        if (isRepeated()) {
                return this.endTime;
        } else {
                return this.time;
        }
        }

        //this method need return interval time of repeatable task
        public int getRepeatInterval() {
                if (this.isRepeated) {
                        return this.repeatInterval;
                }
                else {
                        return 0;
                }
        }

        //isRepeated() return boolean that mean: is repeating in task?
        public boolean isRepeated() {
                return this.isRepeated;
        }

        //toString() return string with information in three cases:
        //Task “<title>” is inactive - when is no active task
        //Task “<title>” at <time>  -when is one active task in some time
        //Task “<title>” from <start> to <end> every <repeat> hours - when is repeatable in every some time
        public String toString() {
                String returningStr;
                returningStr = "";

                if (!this.active) {

                        returningStr = returningStr.concat("Tasc ");
                        returningStr = returningStr.concat(this.title);
                        returningStr = returningStr.concat(" is inactive");

                }
                if ((this.active) & (!this.isRepeated)) {

                        returningStr = returningStr.concat("Tasc ");
                        returningStr = returningStr.concat(this.title);
                        returningStr = returningStr.concat(" at ");
                        returningStr = returningStr.concat(String.valueOf(this.time));


                }

                if ((this.active) & (this.isRepeated)) {

                        returningStr = returningStr.concat("Tasc ");
                        returningStr = returningStr.concat(this.title);
                        returningStr = returningStr.concat(" from ");
                        returningStr = returningStr.concat(String.valueOf(this.start));
                        returningStr = returningStr.concat(" to ");
                        returningStr = returningStr.concat(String.valueOf(this.end));
                        returningStr = returningStr.concat(" every ");
                        returningStr = returningStr.concat(String.valueOf(this.repeat));
                        returningStr = returningStr.concat(" hours ");

                }
        return returningStr;
        }

        //nextTimeAfter(int time) return if it exists next task time after time or return -1 if not active.
        public int nextTimeAfter(int time) {

                if ((!this.active) |
                        (this.endTime < time) |
                        (this.time < time)        ) {
                        return -1;
        }
                if (this.isRepeated) {
                        int i;
                        for (i = this.startTime; this.endTime > i;
                         i = i + this.repeatInterval) {
                                if (i > time) {
                                          return i + this.repeatInterval;
                                }
                         }
                        return -1;
        }
        return -1;
        }

        // This constructor Task(String title, int time) uses when is needed a create and use not
        // repeatable  in code and have two parameters^ String title
        // is  name of task, and int time - is time of task;
        // and this class need some of functions from class Task which are useful in this constructor
        public Task(String title, int time) {
                 title = this.title; // local variable for title of task
                 // local variable for time
                 time = this.time; //
                int repeat=this.repeat;
                boolean active=this.active;
                
        }

        //This constructor Task(String title, int start, int end, int repeat) uses when is needed
        // a new task creating and use with parameters String title - it is name of task,int start is a
        // variable which meaning is  start time, int end meaning is end time for
        // repeatable Task in code and int repeat is parameter which show time for repeating task
        public Task(String title, int start, int end, int repeat) {
                //for (int i = start; i < end; i = i + repeat) in this class may be a cycle for running many tasks

                title = null; // private variable for title of task
                // private variable for
                start = this.start;
                end= this.end;


        }
}

